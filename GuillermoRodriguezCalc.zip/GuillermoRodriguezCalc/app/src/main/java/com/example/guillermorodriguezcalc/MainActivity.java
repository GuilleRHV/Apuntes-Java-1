package com.example.guillermorodriguezcalc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button numero0,numero1,numero2,numero3,numero4,numero5,numero6,numero7,numero8,numero9;
    Button sumar, restar,dividir,multiplicar, igual;
    TextView resultadopantalla,calculos;
    Switch switch2;
    int contseparadores= 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        switch2 = (Switch) findViewById(R.id.switch2);
        numero0 = (Button) findViewById(R.id.number0);
        numero1 = (Button) findViewById(R.id.number1);
        numero2 = (Button) findViewById(R.id.number2);
        numero3 = (Button) findViewById(R.id.number3);
        numero4 = (Button) findViewById(R.id.number4);
        numero5 = (Button) findViewById(R.id.number5);
        numero6 = (Button) findViewById(R.id.number6);
        numero7 = (Button) findViewById(R.id.number7);
        numero8 = (Button) findViewById(R.id.number8);
        numero9 = (Button) findViewById(R.id.number9);

        sumar = (Button) findViewById(R.id.sumar);
        restar = (Button) findViewById(R.id.restar);
        dividir = (Button) findViewById(R.id.dividir);
        multiplicar = (Button) findViewById(R.id.multiplicar);
        igual = (Button) findViewById(R.id.igual);

        resultadopantalla= (TextView) findViewById(R.id.resultadopantalla);
        calculos= (TextView) findViewById(R.id.calculos);
        switch2.setChecked(false);

    }



    public void apuntar(View v) {
        Button b = (Button)v;
        String buttonText = b.getText().toString();

        String valor =  resultadopantalla.getText().toString();
        int i= valor.length();
        String[] valorsum = valor.split("\\+");


            resultadopantalla.setText(valor+String.valueOf(buttonText));





        //String valor =  resultadopantalla.getText().toString();




    }

    public void sumar(View v) {
        boolean separadorpantalla=true;
        String separador="";
        String valortotal =  resultadopantalla.getText().toString();
        if(valortotal.contains("+")){
            separador="\\+";
        } else if(valortotal.contains("-")){
            separador="-";
        } else if(valortotal.contains("X")){
            separador="X";
        } else if(valortotal.contains("/")){
            separador="/";
        } else {
            separadorpantalla=false;
        }
        int resul=0;
        if (separadorpantalla) {
            String codigo[] = valortotal.split(separador);

            if (separador.equalsIgnoreCase("\\+")) {
                resul = Integer.parseInt(codigo[0]) + Integer.parseInt(codigo[1]);
            } else if (separador.equalsIgnoreCase("-")) {
                resul = Integer.parseInt(codigo[0]) - Integer.parseInt(codigo[1]);
            } else if (separador.equalsIgnoreCase("x")) {
                resul = Integer.parseInt(codigo[0]) * Integer.parseInt(codigo[1]);
            } else if (separador.equalsIgnoreCase("/")) {
                resul = Integer.parseInt(codigo[0]) / Integer.parseInt(codigo[1]);
            }

                resultadopantalla.setText(String.valueOf(resul));
                calculos.setText(String.valueOf(resul) + "\\+");


        }

    }


    public void calculo(View v) {
     //   String[] valorsum = valor.split("\\+");
     //   String[] valorsum = valor.split("\\+");
        String separador="";
        String valortotal =  resultadopantalla.getText().toString();
        if(valortotal.contains("+")){
            separador="\\+";
        } else if(valortotal.contains("-")){
            separador="-";
        } else if(valortotal.contains("X")){
            separador="X";
        } else if(valortotal.contains("/")){
            separador="/";
        }

        String codigo[] = valortotal.split(separador);

        double res=0;

        double resul;
        if (separador.equalsIgnoreCase("\\+")){
            resul = Double.parseDouble(codigo[0])+Double.parseDouble(codigo[1]);
        } else if (separador.equalsIgnoreCase("-")){
            resul = Double.parseDouble(codigo[0])-Double.parseDouble(codigo[1]);
        } else if (separador.equalsIgnoreCase("x")){
            resul = Double.parseDouble(codigo[0])*Double.parseDouble(codigo[1]);
        } else if (separador.equalsIgnoreCase("/")){
            resul = Double.parseDouble(codigo[0])/Double.parseDouble(codigo[1]);

        } else {
            resul = 0;
        }
        resultadopantalla.setText(String.valueOf(resul));
        calculos.setText(String.valueOf(resul));

    }



    public void invertir(View v) {
        //   String[] valorsum = valor.split("\\+");
        //   String[] valorsum = valor.split("\\+");
        String separador="";
        String valortotal =  resultadopantalla.getText().toString();
        if(Double.parseDouble(valortotal)<0){
            valortotal=valortotal.replace("-","");
            resultadopantalla.setText(String.valueOf(valortotal));
            calculos.setText(String.valueOf(valortotal));
        }else{
            valortotal="-"+valortotal;
            resultadopantalla.setText(String.valueOf(valortotal));
            calculos.setText(String.valueOf(valortotal));
        }


    }

    public void limpiar(View v) {
        //   String[] valorsum = valor.split("\\+");
        //   String[] valorsum = valor.split("\\+");

        resultadopantalla.setText(String.valueOf(""));



    }

    public void ocultarfunciones(View v) {
        if(switch2.isChecked()){
            switch2.setChecked(false);
        }else{
            switch2.setChecked(true);
        }

    }


    }








