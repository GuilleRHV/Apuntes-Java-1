package Actividad_3x02;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import Ejercicio3x01.AccesoEscritor;
import Ejercicio3x01.Escritor;
import entrada.Teclado;

public class Ejercicio3x02 {

	public static void main(String[] args) throws ClassNotFoundException, IOException {

		int codigolibro, codigoescritor;
		AccesoLibro al = new AccesoLibro();
		int opcion;
		do {
			textoOpciones();
			opcion = Teclado.leerEntero("Introduce opcion");
			switch (opcion) {
			case 0:
				System.out.println("Fin del programa");
				break;
			case 1:
				insertarLibro();
				break;
			case 2:
				leerlibros();
				break;
			case 3:
				codigolibro = Teclado.leerEntero("Introduce codigo libro que desea buscar");
				List<Libro> lista = al.leerfichero();
				Libro libro = al.consultarLibro(codigolibro);
				if (libro != null) {
					System.out.println(libro.toString());

				} else {
					System.out.println("No se ha encontrado el libro con ese codigo");

				}
				break;
			case 4:
				codigolibro = Teclado.leerEntero("Introduce codigo libro que deseas actualizar");
				List<Libro> list = al.leerfichero();
				boolean escontradocodigoescritor = false;
				int escritorcodigoaux = 0;
				int posicioncont = 0;
				int cont = 0;
				Libro lib = al.consultarLibro(codigolibro);
				if (lib != null) {
					codigoescritor = Teclado.leerEntero("Introduce codigo escritor que deseas actualizar");
					List<Escritor> escritores = al.leerficheroescritores();
					if (escritores.size() != 0) {
						System.out.println(list.toString());

						for (Libro l : list) {

							if (l.getCodigo() == codigoescritor || l.getCodigoescritor()==codigoescritor) {
								posicioncont=cont;
								escontradocodigoescritor=true;
							}
							cont++;
						}
					
						
						if (escontradocodigoescritor) {
							
									int nuevocodigoescritor = Teclado.leerEntero("Nuevo codigo escritor:");
							String nuevotitulo = Teclado.leerCadena("Introduce nuevo titulo");
							int nuevoanyopublicacion = Teclado.leerEntero("Introduce nuevo anyo de publicacion");
							double nuevoprecio = Teclado.leerReal("Introduc nuevo precio");
							list.get(posicioncont).setCodigoescritor(nuevocodigoescritor);
							list.get(posicioncont).setTitulo(nuevotitulo);
							list.get(posicioncont).setAnyopublicacion(nuevoanyopublicacion);
							list.get(posicioncont).setPrecio(nuevoprecio);

							al.actualizar(list);
									
						} else {
							System.out.println("No hay ningun escritor con ese codigo");
						}

					} else {
						System.out.println("No hay escritores disponibles");
					}

				} else {
					System.out.println("No se ha encontrado el libro con ese codigo");

				}

				break;

			}
		} while (opcion != 0);

	}

	public static void insertarLibro() throws ClassNotFoundException, IOException {
		AccesoLibro al = new AccesoLibro();
		int codigo = Teclado.leerEntero("Introduce codigo del libro");
		if (al.consultarLibro(codigo) == null) {
			int codigoescritor = Teclado.leerEntero("Introduce codigo del escritor");
			if (al.consultarescritor(codigoescritor) != null) {

				String titulo = Teclado.leerCadena("Introduce titulo");
				int anyopublicacion = Teclado.leerEntero("Introduce anyo de publicacion");
				double precio = Teclado.leerReal("Introduce precio");
				al.escribirLibro(codigo, codigoescritor, titulo, anyopublicacion, precio);
				System.out.println("Se ha escrito un libro");
			} else {
				System.out.println("No existe ningun escritor con ese codigo ");
			}
		} else {
			System.out.println("Ya existe un libro con ese codigo");
		}

	}

	public static void leerlibros() throws ClassNotFoundException, IOException {
		AccesoLibro al = new AccesoLibro();
		List<Libro> libros = al.leerfichero();
		int cont = 0;
		for (Libro libro : libros) {
			System.out.println(libro.toString());
			cont++;
		}
		System.out.println("Hay " + cont + " libros");

	}

	public static void actualizoEscritor(List<Escritor> lista, int codigo) throws FileNotFoundException, IOException {
		AccesoEscritor ae = new AccesoEscritor();

		String nombre = Teclado.leerCadena("Dime el nombre");
		String fecha = Teclado.leerCadena("Dime la fecha");
		String nacionalidad = Teclado.leerCadena("dime la nacionalidad");
		for (Escritor e : lista) {
			if (e.getCodigo() == codigo) {
				e.setFecha(fecha);
				e.setNacionalidad(nacionalidad);
				e.setNombre(nombre);

			}
		}
		ae.actualizar(lista);
		// System.out.println("Se ha actualizado un escritor del fichero binario.");

	}

	public static void textoOpciones() {
		System.out.println("0) Salir del programa");
		System.out.println("1) Insertar un libro en el fichero binario");
		System.out.println("2) Consultar todos los libros del fichero binario.");
		System.out.println("3) Consultar un libro, por c�digo, del fichero de texto");
		System.out.println("4) Actualizar un empleados, por c�digo, del fichero de texto.");
		System.out.println("5) Eliminar un empleado, por c�digo, del fichero de texto");

	}
}
