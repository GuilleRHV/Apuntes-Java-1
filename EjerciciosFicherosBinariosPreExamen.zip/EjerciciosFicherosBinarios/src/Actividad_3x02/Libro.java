package Actividad_3x02;

import java.io.Serializable;

public class Libro  implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public int codigo;
	public int codigoescritor;
	public String titulo;
	public int anyopublicacion;
	public double precio;
	public Libro(int codigo,int codigoescritor, String titulo, int anyopublicacion, double precio) {
		super();
		this.codigo=codigo;
		this.codigoescritor = codigoescritor;
		this.titulo = titulo;
		this.anyopublicacion = anyopublicacion;
		this.precio = precio;
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public int getCodigoescritor() {
		return codigoescritor;
	}
	public void setCodigoescritor(int codigoescritor) {
		this.codigoescritor = codigoescritor;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public int getAnyopublicacion() {
		return anyopublicacion;
	}
	public void setAnyopublicacion(int anyopublicacion) {
		this.anyopublicacion = anyopublicacion;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	@Override
	public String toString() {
		return "Libro [codigo=" + codigo + ", codigoescritor=" + codigoescritor + ", titulo=" + titulo
				+ ", anyopublicacion=" + anyopublicacion + ", precio=" +  String.format("%.2f", precio)  + "]";
	}
	
	
	
	
}
