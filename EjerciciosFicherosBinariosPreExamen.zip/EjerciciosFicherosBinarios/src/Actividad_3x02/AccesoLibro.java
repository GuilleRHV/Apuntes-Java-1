package Actividad_3x02;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import Ejercicio3x01.Escritor;
import Ejercicio3x01.MyObjectOutputStream;

public class AccesoLibro {

	public static String ficheroname = "libros.dat";

	public void escribirLibro(int codigo,int codigoescritor, String titulo, int anyopublicacion, double precio)
			throws IOException, FileNotFoundException {
		ObjectOutputStream flujoSalida1 = null;
		MyObjectOutputStream flujoSalida2 = null;
		Libro libro;
		try {

			libro = new Libro(codigo,codigoescritor,titulo,anyopublicacion,precio);
			File fichero = new File(ficheroname);
			// Insertar el alumno al final del fichero.

			if (fichero.exists()) {
				flujoSalida2 = new MyObjectOutputStream(new FileOutputStream(fichero, true));
				flujoSalida2.writeObject(libro);
			}
			// Crear el fichero e insertar el alumno al principio del fichero.
			else {
				flujoSalida1 = new ObjectOutputStream(new FileOutputStream(fichero));
				flujoSalida1.writeObject(libro);
			}
			System.out.println("Se ha escrito un escritor.");

		} finally {
			try {
				if (flujoSalida1 != null) {
					flujoSalida1.close();
				}
				if (flujoSalida2 != null) {
					flujoSalida2.close();
				}
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}

		}
	}
	
	public Libro consultarLibro(int codigo) throws IOException, ClassNotFoundException {
		ObjectInputStream flujoEntrada = null;
		ObjectOutputStream flujoSalida1 = null;
		MyObjectOutputStream flujoSalida2 = null;
		boolean escontrado = false;
		Libro libro = null;
		try {
			File fichero = new File(ficheroname);
			flujoEntrada = new ObjectInputStream(new FileInputStream(fichero));
			int contadorAlumnos = 0;
			
				while (true) {
					libro = (Libro) flujoEntrada.readObject();
					if (libro.getCodigo() == codigo) {
						return libro;
					} else {
						libro = null;
					}
					// System.out.println(alumno.toString());
					contadorAlumnos++;
				}
			

			
		} finally {
			try {
				if (flujoEntrada != null) {
					flujoEntrada.close();
				}
				return libro;

			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		
	
		}
	}
	
	
	public Escritor consultarescritor(int codigo) throws IOException, ClassNotFoundException {
		ObjectInputStream flujoEntrada = null;
		ObjectOutputStream flujoSalida1 = null;
		MyObjectOutputStream flujoSalida2 = null;
		boolean escontrado = false;
		Escritor escritor = null;
		try {
			File fichero = new File("escritores.dat");
			flujoEntrada = new ObjectInputStream(new FileInputStream(fichero));
			int contadorAlumnos = 0;
			
				while (true) {
					escritor = (Escritor) flujoEntrada.readObject();
					if (escritor.getCodigo() == codigo) {
						return escritor;
					} else {
						escritor = null;
					}
					// System.out.println(alumno.toString());
					contadorAlumnos++;
				}
			

			
		} finally {
			try {
				if (flujoEntrada != null) {
					flujoEntrada.close();
				}
				return escritor;

			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		
	
		}
	}
	
	
	
	

	public List<Libro> leerfichero() throws IOException, ClassNotFoundException {
		List<Libro> lista = new ArrayList<Libro>();
		ObjectInputStream flujoEntrada = null;
		boolean finalfichero = false;
		try {
			File fichero = new File(ficheroname);

			flujoEntrada = new ObjectInputStream(new FileInputStream(fichero));
			int contadorlibro = 0;
			try {
				while (!finalfichero) {
					Libro libro = (Libro) flujoEntrada.readObject();
					lista.add(libro);
					// System.out.println(alumno.toString());
					contadorlibro++;
				}
			} catch (EOFException eofe) {
				finalfichero = true;

				// System.out.println("Se han le�do " + contadorAlumnos + " escritores del
				// fichero binario.");
			}
		} finally {
			try {
				if (flujoEntrada != null) {
					flujoEntrada.close();
				}
				return lista;
			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}

		}
		return lista;

	}
	
	
	public List<Escritor> leerficheroescritores() throws IOException, ClassNotFoundException {
		List<Escritor> lista = new ArrayList<Escritor>();
		ObjectInputStream flujoEntrada = null;
		boolean finalfichero = false;
		try {
			File fichero = new File("escritores.dat");

			flujoEntrada = new ObjectInputStream(new FileInputStream(fichero));
			int contadorlibro = 0;
			try {
				while (!finalfichero) {
					Escritor escritor = (Escritor) flujoEntrada.readObject();
					lista.add(escritor);
					// System.out.println(alumno.toString());
					contadorlibro++;
				}
			} catch (EOFException eofe) {
				finalfichero = true;

				// System.out.println("Se han le�do " + contadorAlumnos + " escritores del
				// fichero binario.");
			}
		} finally {
			try {
				if (flujoEntrada != null) {
					flujoEntrada.close();
				}
				return lista;
			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}

		}
		return lista;

	}
	
	
	public void actualizar(List<Libro> lista) {
		// ObjectOutputStream flujoSalida1 = null;
		ObjectOutputStream flujoSalida2 = null;
		Escritor escritor;
		try {

			File fichero = new File(ficheroname);
			// Insertar el alumno al final del fichero.

			// Crear el fichero e insertar el alumno al principio del fichero.

			flujoSalida2 = new ObjectOutputStream(new FileOutputStream(fichero));
			for (Libro libro : lista) {
				flujoSalida2.writeObject(libro);
			}

			System.out.println("Se ha actualizado un trabajador");
		} catch (FileNotFoundException fnfe) {
			System.out.println("Error al crear o abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			System.out.println("Error al escribir en el fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		} finally {
			try {
				if (flujoSalida2 != null) {
					flujoSalida2.close();
				}

			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}
	}
}
