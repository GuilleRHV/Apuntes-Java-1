package Ejercicios;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import entrada.Teclado;
public class Ejercicio3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		textoOpciones();
		int opcion;
		Ej3Funciones funciones=null;
		do {
			textoOpciones();
			 opcion= Teclado.leerEntero("Introduce opcion");
			 switch (opcion) {
			case 0: 
				break;
			case 1:
				funciones.escribirvariasfrases();
				break;
			case 2:
				funciones.leertodasfrases();
				break;
			case 3:
				funciones.estadisticas();
				break;
			case 4:
				String palabra = Teclado.leerCadena("Introduce la palabra que quieres buscar");
				funciones.encontrarpalabra(palabra);
				break;
			case 5:
				funciones.escribiramayus();
				break;
			case 6:
				funciones.escribirminus();
				break;
			
			default:
				System.out.println("La opción de menú debe estar comprendida entre 0 y 6");
			}
		}while(opcion!=0);
		
	}
	
	
	public static void textoOpciones() {
		System.out.println("0) Salir del programa");
		System.out.println("1) Escribir varias frases en el fichero de texto.");
		System.out.println("2) Leer todas las frases del fichero de texto.");
		System.out.println("3) Consultar el número de líneas y el número de palabras del fichero de texto.");
		System.out.println("4) Buscar una palabra en el fichero de texto.");
		System.out.println("5) Crear otro fichero de texto con las frases del fichero de texto convertidas a mayúsculas.");
		System.out.println("6) Crear otro fichero de texto con las frases del fichero de texto convertidas a minúsculas.");
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
