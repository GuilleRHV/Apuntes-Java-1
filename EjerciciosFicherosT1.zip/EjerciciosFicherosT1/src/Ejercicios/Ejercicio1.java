package Ejercicios;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;



public class Ejercicio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedReader flujoEntrada = null;
		BufferedWriter flujoSalida = null;
		try {
			File salida = new File("salida.txt");
			flujoSalida = new BufferedWriter(new FileWriter(salida, false));
			
			
			
			
			List<String> list = new ArrayList<>();
			List<String> listInvertida = new ArrayList<>();
			File fichero = new File("entrada.txt");
			flujoEntrada = new BufferedReader(new FileReader(fichero));
			int contadorLineas = 0;
      		String linea = flujoEntrada.readLine(); 
      		while (linea != null) { 	 
      			
      			list.add(linea);
      			
      			linea = flujoEntrada.readLine();
      		}
      		
      		for ( int i = list.size()-1; i >= 0; i--) {
      			listInvertida.add(list.get(i));
      			flujoSalida.write(list.get(i));

    			flujoSalida.newLine();
      			System.out.println(list.get(i));
      		}
      		
      		  
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		finally {
			try {
				if(flujoEntrada!=null) {
					flujoEntrada.close();
				}
				if(flujoSalida!=null) {
					flujoSalida.close();
				}
				
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}

}
	
}
