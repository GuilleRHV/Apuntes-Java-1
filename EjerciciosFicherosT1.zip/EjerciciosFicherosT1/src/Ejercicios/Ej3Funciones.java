package Ejercicios;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import entrada.Teclado;

public class Ej3Funciones {


	public static void escribirvariasfrases() {
		String opcion;
		do {
			System.out.println("Escribe lineas:");
			System.out.println("Pulsa '***' para volver al menu");
			opcion = Teclado.leerCadena("Introduce valor");
			if(opcion.equals("***")){
				break;
			}

			BufferedWriter flujoSalida = null;
			try {
				File fichero = new File("frases.txt");
				flujoSalida = new BufferedWriter(new FileWriter(fichero, true));

				flujoSalida.write(opcion);
				flujoSalida.newLine();
				System.out.println("Has escrito una frase con exito");
			} 
			catch (IOException ioe) {
				System.out.println("Error al escribir en el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
			finally {
				try {
					if (flujoSalida != null) {
						flujoSalida.close();
					}
				}
				catch (IOException ioe) {
					System.out.println("Error al cerrar el fichero:");
					System.out.println(ioe.getMessage());
					ioe.printStackTrace();
				}
			}

		}while(!opcion.equals("***"));
	}








	public static void leertodasfrases() {
		BufferedReader flujoEntrada = null;
		try {
			File fichero = new File("frases.txt");
			flujoEntrada = new BufferedReader(new FileReader(fichero));
			int contadorLineas = 0;
			String linea = flujoEntrada.readLine(); 
			while (linea != null) { 	 
				System.out.println(linea);

				linea = flujoEntrada.readLine();
			}


		}
		catch (FileNotFoundException fnfe) {                      
			System.out.println("Error al abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		}
		catch (IOException ioe) {
			System.out.println("Error al leer del fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		}
		finally {
			try {
				if (flujoEntrada != null) {
					flujoEntrada.close();
				}

			}
			catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}
	}




	public static void encontrarpalabra(String palabra) {



		BufferedReader flujoEntrada = null;

		File fichero = new File("frases.txt");

		try {



			flujoEntrada = new BufferedReader(new FileReader(fichero));
			String texto ="";


			String linea = flujoEntrada.readLine(); 
			int contLineas = 0;

			boolean encontrado=false;
			int lineaencontrado=1;
			while (linea != null) { 	 

				String[] palabras = linea.split("\\s+");


				linea = flujoEntrada.readLine();
				texto =" "+linea;
				//tambien se puede usar .trim()
				if(texto.contains(palabra)) {
					lineaencontrado=contLineas;
					encontrado=true;
				}
				contLineas++;
			}


			if(encontrado) {
				System.out.println("Se ha encontrado la palabra solicitada en la linea "+lineaencontrado);
			}else {
				System.out.println("No se ha encontrado la palabra solicitada");
			}



		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		finally {
			try {
				if(flujoEntrada!=null) {
					flujoEntrada.close();
				}


			} catch (Exception e2) {
				// TODO: handle exception
			}
		}


	}


	public static void escribiramayus() {
		String opcion;
		BufferedReader flujoEntrada = null;
		File ficheroentrada = new File("frases.txt");

		BufferedWriter flujoSalida = null;
		try {
			flujoEntrada = new BufferedReader(new FileReader(ficheroentrada));

			File fichero = new File("mayusculas.txt");
			flujoSalida = new BufferedWriter(new FileWriter(fichero, false));



			String linea = flujoEntrada.readLine(); 

			while (linea != null) { 	 

				String[] palabras = linea.split("\\s+");

				String frase = linea;
				flujoSalida.write(frase.toUpperCase());
				linea = flujoEntrada.readLine();

				flujoSalida.newLine();
			}
			System.out.println("Has escrito el archivo en mayuscula en el texto mayusculas.txt");


		} 
		catch (IOException ioe) {
			System.out.println("Error al escribir en el fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		}
		finally {
			try {
				if (flujoSalida != null) {
					flujoSalida.close();
				}

				if(flujoEntrada!=null) {
					flujoEntrada.close();
				}
			}
			catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}


	}





	public static void escribirminus() {
		String opcion;
		BufferedReader flujoEntrada = null;
		File ficheroentrada = new File("frases.txt");

		BufferedWriter flujoSalida = null;
		try {
			flujoEntrada = new BufferedReader(new FileReader(ficheroentrada));

			File fichero = new File("minusculas.txt");
			flujoSalida = new BufferedWriter(new FileWriter(fichero, false));



			String linea = flujoEntrada.readLine(); 

			while (linea != null) { 	 

				String[] palabras = linea.split("\\s+");
				String frase =linea;
				flujoSalida.write(frase.toLowerCase());

				linea = flujoEntrada.readLine();

				flujoSalida.newLine();
			}


		} 
		catch (IOException ioe) {
			System.out.println("Error al escribir en el fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		}
		finally {
			try {
				if (flujoSalida != null) {
					flujoSalida.close();
				}

				if(flujoEntrada!=null) {
					flujoEntrada.close();
				}
				System.out.println("Has escrito el archivo en minuscula en el texto minuscula.txt");
			}
			catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}


	}







	public static void estadisticas() {



		BufferedReader flujoEntrada = null;

		File fichero = new File("frases.txt");

		try {



			flujoEntrada = new BufferedReader(new FileReader(fichero));
			List<Integer> contadorPalabras = new ArrayList<Integer>();
			int contadorPalabrasTotal =0;
			List<Integer> contadorLetras = new ArrayList<Integer>();
			int contadorLetrasTotal=0;

			String linea = flujoEntrada.readLine(); 
			int contLineas = 0;
			while (linea != null) { 	 

				String[] palabras = linea.split("\\s+");

				contadorPalabras.add(palabras.length);
				contadorPalabrasTotal+=palabras.length;
				//System.out.println(linea);
				contadorLetras.add(linea.length());
				contadorLetrasTotal+=linea.length();
				linea = flujoEntrada.readLine();
				contLineas++;
			}

			System.out.println("Total:"+contLineas+" líneas,"+contadorLetrasTotal+" caracteres y "+contadorPalabrasTotal+" palabras");




		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		finally {
			try {
				if(flujoEntrada!=null) {
					flujoEntrada.close();
				}


			} catch (Exception e2) {
				// TODO: handle exception
			}
		}	

	}

}
