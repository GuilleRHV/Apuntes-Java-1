package EjerciciosFicherosBinarios;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.StreamCorruptedException;
import java.util.ArrayList;
import java.util.List;

import entrada.Teclado;

public class Actividad_3x01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int opcion = 1;
		int codigo;
		String nombre = "";
		String fecha = "";
		String nacionalidad = "";
		File fichero = new File("trabajadores.dat");
		AccesoEscritor ae = new AccesoEscritor();
		do {
			manuopciones();
			System.out.println();
			opcion = Teclado.leerEntero("Introduce opcion");
			//try {
				switch (opcion) {
				case 1:
					codigo = Teclado.leerEntero("Introduce codigo");
					if (!fichero.exists()) {
						nombre = Teclado.leerCadena("Introduce nombre");
						fecha = Teclado.leerCadena("Introduce fecha");
						nacionalidad = Teclado.leerCadena("Introduce nacionalidad");
						ae.escribirEscritor(codigo, nombre, fecha, nacionalidad);
						System.out.println("Escritor insertado");
					} else if (ae.codigovalido(codigo)!=null) {

						nombre = Teclado.leerCadena("Introduce nombre");
						fecha = Teclado.leerCadena("Introduce fecha");
						nacionalidad = Teclado.leerCadena("Introduce nacionalidad");
						ae.escribirEscritor(codigo, nombre, fecha, nacionalidad);
						System.out.println("Escritor insertado");
					}

					else {
						System.out.println("Codigo repetido");
					}
					break;
				case 2:

					List<Escritor> lista = ae.leerfichero();
					for (Escritor escritor : lista) {
						System.out.println(escritor.toString());
					}

					break;
				case 3:
					codigo = Teclado.leerEntero("Introduce codigo escritor");
					Escritor esc = ae.consultarescritor(codigo);
					if (esc != null) {
						System.out.println(esc.toString());
					} else {
						System.out.println("No se ha encontrado el escritor con ese codigo");

					}
					break;
				case 4:
					codigo = Teclado.leerEntero("Introduce codigo escritor que quieres actualizar");
					Escritor escr = ae.consultarescritor(codigo);
					if (escr != null) {
						List<Escritor> lista2 = ae.leerfichero();
						
						try {
							actualizoEscritor(lista2, codigo);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					} else {
						System.out.println("No se ha encontrado el escritor con ese codigo");

					}
					break;
				default:
					System.out.println("Valor no valido");
					break;
				
				}
			/*} catch (FileNotFoundException e) {
				e.getStackTrace();
				
			} catch (StreamCorruptedException e) {
				// TODO: handle exception
			} catch (IOException ioe) {

			} catch (ClassNotFoundException cnfe) {
				// TODO: handle exception
			}*/
			
		} while (opcion != 0);
	}

	public static void manuopciones() {
		String frase = "0) Salir del programa\n1) Insertar un escritor en el fichero binario\n2) Consultar todos los escritores del fichero binario."
				+ "\n3) Consultar un escritor, por código, del fichero binario\n4) Actualizar un escritor, por código, del fichero binario.\r\n"
				+ "";
		System.out.println(frase);
	}
	
	
	public static void actualizoEscritor(List<Escritor> lista, int codigo) throws FileNotFoundException, IOException {
		AccesoEscritor ae=new AccesoEscritor();
		

		String nombre = Teclado.leerCadena("Dime el nombre");
		String fecha = Teclado.leerCadena("Dime la fecha");
		String nacionalidad = Teclado.leerCadena("dime la nacionalidad");
		for (Escritor e : lista) {
			if (e.getCodigo() == codigo) {
				e.setFecha(fecha);
				e.setNacionalidad(nacionalidad);
				e.setNombre(nombre);
				
			}
		}
		ae.actualizar(lista);
		//System.out.println("Se ha actualizado un escritor del fichero binario.");

	}
	/*
	public static void consultaEscritores() {
		List<Escritor> escritores = new ArrayList<>();
		escritores = AccesoEscritor.consultaEscritores();
		if (!escritores.isEmpty()) {
			for (Escritor e : escritores) {
				System.out.println(e);
			}
		} else {
			System.err.println("Error el fichero esta vacio");
		}
	}
	
	
	public static void consultaEscritores() {
		List<Escritor> escritores = new ArrayList<>();
		escritores = AccesoEscritor.consultaEscritores();
		if (!escritores.isEmpty()) {
			for (Escritor e : escritores) {
				System.out.println(e);
			}
		} else {
			System.err.println("Error el fichero esta vacio");
		}
	}
	*/
}
