package EjerciciosFicherosBinarios;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;
import java.util.ArrayList;
import java.util.List;

import entrada.Teclado;
import EjerciciosFicherosBinarios.MyObjectOutputStream;

import EjerciciosFicherosBinarios.Escritor;

public class AccesoEscritor {
	public static String ficheroname = "escritores.dat";

	public void escribirEscritor(int codigo, String nombre, String fecha, String nacionalidad) {
		ObjectOutputStream flujoSalida1 = null;
		MyObjectOutputStream flujoSalida2 = null;
		Escritor escritor;
		try {

			escritor = new Escritor(codigo, nombre, fecha, nacionalidad);
			File fichero = new File(ficheroname);
			// Insertar el alumno al final del fichero.
			
			
			if (fichero.exists()) {
				flujoSalida2 = new MyObjectOutputStream(new FileOutputStream(fichero, true));
				flujoSalida2.writeObject(escritor);
			}
			// Crear el fichero e insertar el alumno al principio del fichero.
			else {
				flujoSalida1 = new ObjectOutputStream(new FileOutputStream(fichero));
				flujoSalida1.writeObject(escritor);
			}
			System.out.println("Se ha escrito un alumno en el fichero binario.");
		} catch (FileNotFoundException fnfe) {
			System.out.println("Error al crear o abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			System.out.println("Error al escribir en el fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		} finally {
			try {
				if (flujoSalida1 != null) {
					flujoSalida1.close();
				}
				if (flujoSalida2 != null) {
					flujoSalida2.close();
				}
			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}
	}
	
	
	
	
	
	
	public void escribirTodos(List<Escritor> lista) {
		ObjectOutputStream flujoSalida1 = null;
		MyObjectOutputStream flujoSalida2 = null;
		Escritor escritor;
		try {

			
			File fichero = new File(ficheroname);
			// Insertar el alumno al final del fichero.
			
			
			if (fichero.exists()) {
				flujoSalida2 = new MyObjectOutputStream(new FileOutputStream(fichero, true));
				for (Escritor escritor2 : lista) {
					flujoSalida2.writeObject(escritor2);
				}
				
			}
			// Crear el fichero e insertar el alumno al principio del fichero.
			else {
				flujoSalida1 = new ObjectOutputStream(new FileOutputStream(fichero));
				for (Escritor escritor2 : lista) {
					flujoSalida2.writeObject(escritor2);
				}
			}
			System.out.println("Se ha escrito varios alumno en el fichero binario.");
		} catch (FileNotFoundException fnfe) {
			System.out.println("Error al crear o abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			System.out.println("Error al escribir en el fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		} finally {
			try {
				if (flujoSalida1 != null) {
					flujoSalida1.close();
				}
				if (flujoSalida2 != null) {
					flujoSalida2.close();
				}
			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}
	}
	
	
	
	public void actualizar(List<Escritor> lista) {
		ObjectOutputStream flujoSalida1 = null;
		MyObjectOutputStream flujoSalida2 = null;
		Escritor escritor;
		try {

			
			File fichero = new File(ficheroname);
			// Insertar el alumno al final del fichero.
			
			
			// Crear el fichero e insertar el alumno al principio del fichero.
			
				flujoSalida1 = new ObjectOutputStream(new FileOutputStream(fichero));
				for (Escritor escritor2 : lista) {
					flujoSalida2.writeObject(escritor2);
				}
			
			System.out.println("Se ha escrito varios alumno en el fichero binario.");
		} catch (FileNotFoundException fnfe) {
			System.out.println("Error al crear o abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			System.out.println("Error al escribir en el fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		} finally {
			try {
				if (flujoSalida1 != null) {
					flujoSalida1.close();
				}
				if (flujoSalida2 != null) {
					flujoSalida2.close();
				}
			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}
	}
	

	public List<Escritor> leerfichero() {
		List<Escritor> lista = new ArrayList<Escritor>();
		ObjectInputStream flujoEntrada = null;
		boolean finalfichero=false;
		try {
			File fichero = new File(ficheroname);
			
			flujoEntrada = new ObjectInputStream(new FileInputStream(fichero));
			int contadorAlumnos = 0;
			try {
				while (!finalfichero) {
					Escritor alumno = (Escritor) flujoEntrada.readObject();
					lista.add(alumno);
					//System.out.println(alumno.toString());
					contadorAlumnos++;
				}
			} catch (EOFException eofe) {
				finalfichero = true;
			} catch (StreamCorruptedException sce) {
				System.out.println("Se ha encontrado informaci�n inconsistente en el fichero binario.");
			}
			System.out.println("Se han le�do " + contadorAlumnos + " escritores del fichero binario.");
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Error al convertir objeto a una clase:");
			System.out.println(cnfe.getMessage());
			cnfe.printStackTrace();
		} catch (FileNotFoundException fnfe) {
			System.out.println("Error al abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			System.out.println("Error al leer del fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		} finally {
			try {
				if (flujoEntrada != null) {
					flujoEntrada.close();
				}
				return lista;
			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
			
		
		}
		return lista;
	}
	
	public static List<Escritor> leerEscritores() throws IOException, ClassNotFoundException {
		ObjectInputStream flujoEntrada = null;
		List<Escritor> lista = new ArrayList<Escritor>();
		boolean finalfichero=false;
		try {
			File fichero = new File(ficheroname);
			
			flujoEntrada = new ObjectInputStream(new FileInputStream(fichero));
			
					
		}catch (Exception e) {
			// TODO: handle exception
		}
		return lista;
	}
	
	public static List<Escritor> consultaEscritores(){
    	List<Escritor> escritores = new ArrayList<>();
        try (ObjectInputStream archivoEntrada = new ObjectInputStream(new FileInputStream(ficheroname))) {
        	escritores = (ArrayList<Escritor>) archivoEntrada.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return escritores;
    }

	public Escritor codigovalido(int codigo) {
		ObjectInputStream flujoEntrada = null;
		boolean valido = true;
		ObjectOutputStream flujoSalida1 = null;
		MyObjectOutputStream flujoSalida2 = null;
		Escritor escritor =null;
		try {
			File fichero = new File("escritores.dat");
			flujoEntrada = new ObjectInputStream(new FileInputStream(fichero));
			int contadorAlumnos = 0;

			// Insertar el alumno al final del fichero.

			try {
				while (true) {
					Escritor aux = (Escritor) flujoEntrada.readObject();
					if (aux.getCodigo() == codigo) {
						escritor = (Escritor) flujoEntrada.readObject();
					}
					// System.out.println(alumno.toString());
					contadorAlumnos++;
				}

			} catch (EOFException eofe) {
				System.out.println("Se ha alcanzado el final del fichero binario.");
			} catch (StreamCorruptedException sce) {
				System.out.println("Se ha encontrado informaci�n inconsistente en el fichero binario.");
			}
			System.out.println("Se han le�do " + contadorAlumnos + " alumnos del fichero binario.");
			} catch (ClassNotFoundException cnfe) {
			System.out.println("Error al convertir objeto a una clase:");
			System.out.println(cnfe.getMessage());
			cnfe.printStackTrace();
		} catch (FileNotFoundException fnfe) {
			System.out.println("Error al abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			System.out.println("Error al leer del fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		} finally {
			try {
				if (flujoEntrada != null) {
					flujoEntrada.close();
				}
				
			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}

		}
		return escritor;
	}

	
	 public static void escribirEscritor(Escritor e) throws IOException, FileNotFoundException {
	        List<Escritor> escritores = consultaEscritores();
	        escritores.add(e);
	        
	        try (ObjectOutputStream archivoSalida = new ObjectOutputStream(new FileOutputStream(ficheroname))) {
	            
	        	archivoSalida.writeObject(escritores);
	            //System.out.println("Empleado guardados en " + NOMBRE_FICHERO);
	        }
	    }
	
	public Escritor consultarescritor(int codigo) {
		ObjectInputStream flujoEntrada = null;
		ObjectOutputStream flujoSalida1 = null;
		MyObjectOutputStream flujoSalida2 = null;
		boolean escontrado = false;
		Escritor escritor = null;
		try {
			File fichero = new File("escritores.dat");
			flujoEntrada = new ObjectInputStream(new FileInputStream(fichero));
			int contadorAlumnos = 0;
			try {
				while (true) {
					escritor = (Escritor) flujoEntrada.readObject();
					if (escritor.getCodigo() == codigo) {
						return escritor;
					} else {
						escritor = null;
					}
					// System.out.println(alumno.toString());
					contadorAlumnos++;
				}

			} catch (EOFException eofe) {
				System.out.println("Se ha alcanzado el final del fichero binario.");
			} catch (StreamCorruptedException sce) {
				System.out.println("Se ha encontrado informaci�n inconsistente en el fichero binario.");
			}
			System.out.println("Se han le�do " + contadorAlumnos + " alumnos del fichero binario.");
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Error al convertir objeto a una clase:");
			System.out.println(cnfe.getMessage());
			cnfe.printStackTrace();
		} catch (FileNotFoundException fnfe) {
			System.out.println("Error al abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			System.out.println("Error al leer del fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		} finally {
			try {
				if (flujoEntrada != null) {
					flujoEntrada.close();
				}
				return escritor;

			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}

		}
		return escritor;

	}

	public void actualizarescritor(int codigo, String nombre, String fecha, String nacionalidad) {
		ObjectInputStream flujoEntrada = null;
		boolean escontrado = false;
		ObjectOutputStream flujoSalida1 = null;
		MyObjectOutputStream flujoSalida2 = null;
		Escritor escritor = null;
		List<Escritor> lista = new ArrayList<>();
		try {
			File fichero = new File("escritores.dat");
			flujoEntrada = new ObjectInputStream(new FileInputStream(fichero));
			int contadorAlumnos = 0;
			try {
				while (true) {
					escritor = (Escritor) flujoEntrada.readObject();
					if (escritor.getCodigo() == codigo) {
						escritor.setFecha(fecha);
						escritor.setNacionalidad(nacionalidad);
						escritor.setNombre(nombre);
						lista.add(escritor);
					} else {
						lista.add(escritor);
					}

					// System.out.println(alumno.toString());
					contadorAlumnos++;
				}

			} catch (EOFException eofe) {
				if (fichero.exists()) {
					flujoSalida2 = new MyObjectOutputStream(new FileOutputStream(fichero, true));
					for (Escritor escritor2 : lista) {
						flujoSalida2.writeObject(escritor2);
					}

				}
				// Crear el fichero e insertar el alumno al principio del fichero.
				else {
					flujoSalida1 = new ObjectOutputStream(new FileOutputStream(fichero));

					for (Escritor escritor2 : lista) {
						flujoSalida2.writeObject(escritor2);
					}
				}
				System.out.println("Se ha alcanzado el final del fichero binario.");
			} catch (StreamCorruptedException sce) {
				System.out.println("Se ha encontrado informaci�n inconsistente en el fichero binario.");
			}
			System.out.println("Se han le�do " + contadorAlumnos + " alumnos del fichero binario.");
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Error al convertir objeto a una clase:");
			System.out.println(cnfe.getMessage());
			cnfe.printStackTrace();
		} catch (FileNotFoundException fnfe) {
			System.out.println("Error al abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			System.out.println("Error al leer del fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		} finally {
			try {
				if (flujoEntrada != null) {
					flujoEntrada.close();
				}

			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}

		}

	}

}
