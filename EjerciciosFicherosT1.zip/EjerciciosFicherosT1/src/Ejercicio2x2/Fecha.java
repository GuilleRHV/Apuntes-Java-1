package Ejercicio2x2;

public class Fecha {
	int dia;
	int mes;
	int anyo;
	final String SEPARADOR="/";
	public Fecha(int dia, int mes, int anyo) {
		super();
		this.dia = dia;
		this.mes = mes;
		this.anyo = anyo;
	}
	@Override
	public String toString() {
		return "Fecha [dia=" + dia + ", mes=" + mes + ", anyo=" + anyo + "]";
	}
	public String toStringWithSeparators() {
		return this.dia+SEPARADOR+this.mes+SEPARADOR+this.anyo;
	}
}
