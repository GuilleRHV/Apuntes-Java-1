package Actividad2;

public class Departamento {
	public int codigo;
	public String nombre;
	public String ubicacion;
	final String SEPARADOR =";";
	
	public Departamento(int codigo, String nombre, String ubicacion) {
		super();
		this.codigo = codigo;
		this.nombre = nombre;
		this.ubicacion = ubicacion;
	}
	
	public Departamento(String datos) {
		String[] palabras = datos.split(";");

		this.codigo=Integer.parseInt(palabras[0]) ;
		this.nombre=palabras[1];
		this.ubicacion=palabras[2];
		
		
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getUbicacion() {
		return ubicacion;
	}
	public void setUbicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}
	@Override
	public String toString() {
		return "Departamento [codigo=" + codigo + ", nombre=" + nombre + ", ubicacion=" + ubicacion + "]";
	}
	
	public String toStringWithSeparators() {
		return this.codigo+SEPARADOR+this.nombre+SEPARADOR+this.ubicacion;
		
	}
	
}
