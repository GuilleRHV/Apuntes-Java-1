package Actividad2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import entrada.Teclado;

public class AccesoDepartamento {

	public static int contador = 0;

	// TODOS LOS SYSO EN EL MAIN

	Departamento departamento = null;

	public void crearDepartamento() {
		String nombre = Teclado.leerCadena("Introduce nombre departamento");
		String ubicacion = Teclado.leerCadena("Introduce ubicacion departamento");

		departamento = new Departamento(contador, nombre, ubicacion);
		contador++;

		escribirenfichero("departamentos.txt", departamento.toStringWithSeparators());
		System.out.println("Departamento creado con exito");
	}

	public static void escribirenfichero(String filename, String frase) {
		BufferedWriter flujoSalida = null;
		try {
			File fichero = new File(filename);
			flujoSalida = new BufferedWriter(new FileWriter(fichero, true));
			flujoSalida.write(frase);
			flujoSalida.newLine();

		} catch (IOException ioe) {
			System.out.println("Error al escribir en el fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		} finally {
			try {
				if (flujoSalida != null) {
					flujoSalida.close();
				}

			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}
	}

	public void leerfichero(String filename) {
		BufferedReader flujoEntrada = null;
		try {
			File fichero = new File(filename);
			flujoEntrada = new BufferedReader(new FileReader(fichero));
			int contadorLineas = 0;
			String linea = flujoEntrada.readLine();
			Departamento departamento = null;
			while (linea != null) {
				departamento = new Departamento(linea);
				System.out.println(departamento.toString());
				contadorLineas++;
				linea = flujoEntrada.readLine();
			}
			if (contadorLineas > 0) {
				System.out.println("Se han encontrado " + contadorLineas + " departamentos.");
			} else {
				System.out.println("No se han encontrado departamentos");
			}

		} catch (FileNotFoundException fnfe) {
			System.out.println("Error al abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			System.out.println("Error al leer del fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		} finally {
			try {
				if (flujoEntrada != null) {
					flujoEntrada.close();
				}
			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}
	}

	public void consultarporid(String filename, int id) {
		BufferedReader flujoEntrada = null;
		try {
			File fichero = new File(filename);
			flujoEntrada = new BufferedReader(new FileReader(fichero));
			boolean encontrado = false;
			String linea = flujoEntrada.readLine();
			Departamento departamento = null;
			while (linea != null) {
				String lineas[] = linea.split(";");
				if (Integer.parseInt(lineas[0]) == id) {
					departamento = new Departamento(linea);
					System.out.println(departamento.toString());
					encontrado = true;
				}
				linea = flujoEntrada.readLine();
			}
			if (!encontrado) {
				System.out.println("No se ha encotnrado ningun departamento con el id pasado");
			}

		} catch (FileNotFoundException fnfe) {
			System.out.println("Error al abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			System.out.println("Error al leer del fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		} finally {
			try {
				if (flujoEntrada != null) {
					flujoEntrada.close();
				}
			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}
	}

	// Falta este
	public void actualizarDepartamento(String filename, int id) {
		BufferedReader flujoEntrada = null;
		BufferedWriter flujoSalida = null;
		try {
			File fichero = new File(filename);
			flujoEntrada = new BufferedReader(new FileReader(fichero));

			List<String> aux = new ArrayList<String>();
			boolean encontrado = false;
			String linea = flujoEntrada.readLine();
			Departamento departamento = null;
			while (linea != null) {
				String lineas[] = linea.split(";");
				System.out.println(linea);
				if (Integer.parseInt(lineas[0]) == id) {
					encontrado = true;
					departamento = new Departamento(linea);
					System.out.println(departamento.toString());
					String nuevodepartamento = actualizarconid(id);
					aux.add(nuevodepartamento);
					// flujoSalida.write(nuevodepartamento);

				} else {
					aux.add(linea);
					// flujoSalida.write(linea);
				}
				linea = flujoEntrada.readLine();
				// flujoSalida.newLine();
			}

			flujoSalida = new BufferedWriter(new FileWriter(filename));
			for (String string : aux) {
				flujoSalida.write(string);
				flujoSalida.newLine();
			}

		} catch (FileNotFoundException fnfe) {
			System.out.println("Error al abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			System.out.println("Error al leer del fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		} finally {
			try {
				if (flujoEntrada != null) {
					flujoEntrada.close();
				}
				if (flujoSalida != null) {
					flujoSalida.close();
				}
			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}
	}

	public String actualizarconid(int id) {
		String nombre = Teclado.leerCadena("Introduce nuevo nombre");
		String ubicacion = Teclado.leerCadena("Introduce nueva ubicacion");
		departamento = new Departamento(id, nombre, ubicacion);
		return departamento.toStringWithSeparators();
	}

	public static void indicefinal() {
		BufferedReader flujoEntrada = null;
		try {
			File fichero = new File("departamentos.txt");
			flujoEntrada = new BufferedReader(new FileReader(fichero));

			String linea = flujoEntrada.readLine();
			while (linea != null) {
				// System.out.println(linea);
				String[] lineas = linea.split(";");
				contador = Integer.parseInt(lineas[0]) + 1;
				linea = flujoEntrada.readLine();
			}

		} catch (FileNotFoundException fnfe) {
			System.out.println("Error al abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			System.out.println("Error al leer del fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		} finally {
			try {
				if (flujoEntrada != null) {
					flujoEntrada.close();
				}
			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}
	}

	public void eliminarDepartamento(String filename, int id) {
		BufferedReader flujoEntrada = null;
		BufferedWriter flujoSalida = null;
		try {
			File fichero = new File(filename);
			flujoEntrada = new BufferedReader(new FileReader(fichero));

			List<String> aux = new ArrayList<String>();
			boolean encontrado = false;
			String linea = flujoEntrada.readLine();
			Departamento departamento = null;
			while (linea != null) {
				String lineas[] = linea.split(";");
				System.out.println(linea);
				if (Integer.parseInt(lineas[0]) == id) {
					encontrado = true;
					// flujoSalida.write(nuevodepartamento);
				} else {
					aux.add(linea);
					// flujoSalida.write(linea);
				}
				linea = flujoEntrada.readLine();
				// flujoSalida.newLine();
			}

			flujoSalida = new BufferedWriter(new FileWriter(filename));
			for (String string : aux) {
				flujoSalida.write(string);
				flujoSalida.newLine();
			}

			if (!encontrado) {
				System.out.println("No existe ningun departamento con ese id");
			}
		} catch (FileNotFoundException fnfe) {
			System.out.println("Error al abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			System.out.println("Error al leer del fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		} finally {
			try {
				if (flujoEntrada != null) {
					flujoEntrada.close();
				}
				if (flujoSalida != null) {
					flujoSalida.close();
				}
			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}
	}

}
