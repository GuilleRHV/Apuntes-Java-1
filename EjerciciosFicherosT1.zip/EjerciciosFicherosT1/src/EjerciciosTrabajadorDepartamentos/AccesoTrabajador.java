package EjerciciosTrabajadorDepartamentos;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;

import entrada.Teclado;



public class AccesoTrabajador {

	public void escribirTrabajador(int codigo,String nombre, int sueldo) {
		ObjectOutputStream flujoSalida1 = null;
		MyObjectOutputStream flujoSalida2 = null;
		Trabajador trabajador;
		try {
			
			trabajador= new Trabajador(codigo, nombre, sueldo);
			File fichero = new File("trabajadores.dat");
			// Insertar el alumno al final del fichero.
			if (fichero.exists()) {
				flujoSalida2 = new MyObjectOutputStream(new FileOutputStream(fichero, true));
				flujoSalida2.writeObject(trabajador);
			}
			// Crear el fichero e insertar el alumno al principio del fichero.
			else {
				flujoSalida1 = new ObjectOutputStream(new FileOutputStream(fichero));
				flujoSalida1.writeObject(trabajador);
			}
			System.out.println("Se ha escrito un alumno en el fichero binario.");
		} 
		catch (FileNotFoundException fnfe) {
			System.out.println("Error al crear o abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		}
		catch (IOException ioe) {
			System.out.println("Error al escribir en el fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		}
		finally {
			try {
				if (flujoSalida1 != null) {
					flujoSalida1.close();
				}
				if (flujoSalida2 != null) {
					flujoSalida2.close();
				}
			}
			catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}
	}
	
	
	
	
public void leerfichero() {
	ObjectInputStream flujoEntrada = null;
	try {
		File fichero = new File("trabajadores.dat");
		flujoEntrada = new ObjectInputStream(new FileInputStream(fichero));
		int contadorTrabajadores = 0;
		try {
			while (true) {
				Trabajador trabajador = (Trabajador) flujoEntrada.readObject();
				System.out.println(trabajador.toString());
				contadorTrabajadores++;
			}
		}
		catch (EOFException eofe) {
			System.out.println("Se ha alcanzado el final del fichero binario.");
		}
		catch (StreamCorruptedException sce) {
			System.out.println("Se ha encontrado informaci�n inconsistente en el fichero binario.");
		}
		System.out.println("Se han le�do " + contadorTrabajadores + 
                           " trabajador del fichero binario.");
	} 
	catch (ClassNotFoundException cnfe) {
		System.out.println("Error al convertir objeto a una clase:");
		System.out.println(cnfe.getMessage());
		cnfe.printStackTrace();
	}
	catch (FileNotFoundException fnfe) {
		System.out.println("Error al abrir el fichero:");
		System.out.println(fnfe.getMessage());
		fnfe.printStackTrace();
	}
	catch (IOException ioe) {
		System.out.println("Error al leer del fichero:");
		System.out.println(ioe.getMessage());
		ioe.printStackTrace();
	}
	finally {
		try {
			if (flujoEntrada != null) {
				flujoEntrada.close();
			}
		}
		catch (IOException ioe) {
			System.out.println("Error al cerrar el fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		}
	}
}

public boolean codigovalido(int codigo) {
	ObjectInputStream flujoEntrada = null;
	ObjectOutputStream flujoSalida1 = null;
	MyObjectOutputStream flujoSalida2 = null;
	boolean valido = true;
	try {
		File fichero = new File("trabajadores.dat");
		flujoEntrada = new ObjectInputStream(new FileInputStream(fichero));
		int contadorAlumnos = 0;
		try {
			
			if (fichero.exists()) {
				flujoSalida2 = new MyObjectOutputStream(new FileOutputStream(fichero, true));
		
			}
			// Crear el fichero e insertar el alumno al principio del fichero.
			else {
				flujoSalida1 = new ObjectOutputStream(new FileOutputStream(fichero));
				
			}
			while (true) {
				Trabajador trabajador = (Trabajador) flujoEntrada.readObject();
				if(trabajador.getCodigo()==codigo) {
					valido = false;
				}
				//System.out.println(alumno.toString());
				contadorAlumnos++;
			}
			
			
		}
		catch (EOFException eofe) {
			System.out.println("Se ha alcanzado el final del fichero binario.");
		}
		catch (StreamCorruptedException sce) {
			System.out.println("Se ha encontrado informaci�n inconsistente en el fichero binario.");
		}
		System.out.println("Se han le�do " + contadorAlumnos + 
                           " alumnos del fichero binario.");
	} 
	catch (ClassNotFoundException cnfe) {
		System.out.println("Error al convertir objeto a una clase:");
		System.out.println(cnfe.getMessage());
		cnfe.printStackTrace();
	}
	catch (FileNotFoundException fnfe) {
		System.out.println("Error al abrir el fichero:");
		System.out.println(fnfe.getMessage());
		fnfe.printStackTrace();
	}
	catch (IOException ioe) {
		System.out.println("Error al leer del fichero:");
		System.out.println(ioe.getMessage());
		ioe.printStackTrace();
	}
	finally {
		try {
			if (flujoEntrada != null) {
				flujoEntrada.close();
			}
			if(flujoSalida2!=null) {
				flujoSalida2.close();
			}
			if(flujoSalida1!=null) {
				flujoSalida1.close();
			}
			return valido;
		}
		catch (IOException ioe) {
			System.out.println("Error al cerrar el fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		}
		
	}
	return valido;
}




public Trabajador consultarTrabajador(int codigo) {
	ObjectInputStream flujoEntrada = null;
	boolean escontrado = false;
	Trabajador trabajador = null;
	try {
		File fichero = new File("trabajadores.dat");
		flujoEntrada = new ObjectInputStream(new FileInputStream(fichero));
		int contadorAlumnos = 0;
		try {
			while (true) {
				trabajador = (Trabajador) flujoEntrada.readObject();
				if(trabajador.getCodigo()==codigo) {
					return trabajador;
				}else {
					trabajador=null;
				}
				//System.out.println(alumno.toString());
				contadorAlumnos++;
			}
			
			
		}
		catch (EOFException eofe) {
			System.out.println("Se ha alcanzado el final del fichero binario.");
		}
		catch (StreamCorruptedException sce) {
			System.out.println("Se ha encontrado informaci�n inconsistente en el fichero binario.");
		}
		System.out.println("Se han le�do " + contadorAlumnos + 
                           " alumnos del fichero binario.");
	} 
	catch (ClassNotFoundException cnfe) {
		System.out.println("Error al convertir objeto a una clase:");
		System.out.println(cnfe.getMessage());
		cnfe.printStackTrace();
	}
	catch (FileNotFoundException fnfe) {
		System.out.println("Error al abrir el fichero:");
		System.out.println(fnfe.getMessage());
		fnfe.printStackTrace();
	}
	catch (IOException ioe) {
		System.out.println("Error al leer del fichero:");
		System.out.println(ioe.getMessage());
		ioe.printStackTrace();
	}
	finally {
		try {
			if (flujoEntrada != null) {
				flujoEntrada.close();
			}
			return trabajador;
			
		}
		catch (IOException ioe) {
			System.out.println("Error al cerrar el fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		}
		
	}
	return trabajador;
	
}




public void actualizarTrabajador(int codigo) {
	ObjectInputStream flujoEntrada = null;
	boolean escontrado = false;
	Trabajador trabajador = null;
	try {
		File fichero = new File("trabajadores.dat");
		flujoEntrada = new ObjectInputStream(new FileInputStream(fichero));
		int contadorAlumnos = 0;
		try {
			while (true) {
				trabajador = (Trabajador) flujoEntrada.readObject();
				if(trabajador.getCodigo()==codigo) {
					
				}else {
					trabajador=null;
				}
				//System.out.println(alumno.toString());
				contadorAlumnos++;
			}
			
			
		}
		catch (EOFException eofe) {
			System.out.println("Se ha alcanzado el final del fichero binario.");
		}
		catch (StreamCorruptedException sce) {
			System.out.println("Se ha encontrado informaci�n inconsistente en el fichero binario.");
		}
		System.out.println("Se han le�do " + contadorAlumnos + 
                           " alumnos del fichero binario.");
	} 
	catch (ClassNotFoundException cnfe) {
		System.out.println("Error al convertir objeto a una clase:");
		System.out.println(cnfe.getMessage());
		cnfe.printStackTrace();
	}
	catch (FileNotFoundException fnfe) {
		System.out.println("Error al abrir el fichero:");
		System.out.println(fnfe.getMessage());
		fnfe.printStackTrace();
	}
	catch (IOException ioe) {
		System.out.println("Error al leer del fichero:");
		System.out.println(ioe.getMessage());
		ioe.printStackTrace();
	}
	finally {
		try {
			if (flujoEntrada != null) {
				flujoEntrada.close();
			}
		
			
		}
		catch (IOException ioe) {
			System.out.println("Error al cerrar el fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		}
		
	}

	
}




}
