package EjerciciosTrabajadorDepartamentos;

import entrada.Teclado;

public class Actividad_3x01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int opcion=1;
		int codigo;
		String nombre="";
		String fecha="";
		int sueldo;
		AccesoTrabajador ae=new AccesoTrabajador();
		do {
			manuopciones();
			System.out.println();
			opcion = Teclado.leerEntero("Introduce opcion");
			switch (opcion) {
			case 1: 
				codigo=Teclado.leerEntero("Introduce codigo");
				if (ae.codigovalido(codigo)) {
					
				
				nombre=Teclado.leerCadena("Introduce nombre");
				
				sueldo = Teclado.leerEntero("Introduce sueldo");
				ae.escribirTrabajador(codigo, nombre, codigo);
				System.out.println("trabajador insertado");
				} else {
					System.out.println("Codigo repetido");
				}
				break;
			case 2:
				
				ae.leerfichero();
				
				break;
			case 3:
				codigo = Teclado.leerEntero("Introduce codigo trabajador");
				Trabajador esc= ae.consultarTrabajador(codigo);
				if (esc!=null) {
					System.out.println(esc.toString());
				}else {
					System.out.println("No se ha encontrado el escritor con ese codigo");
					
				}
				break;
			case 4:
				codigo = Teclado.leerEntero("Introduce codigo escritor que quieres actualizar");
				Trabajador escr= ae.consultarTrabajador(codigo);
				if (escr!=null) {
					System.out.println(escr.toString());
				}else {
					System.out.println("No se ha encontrado el escritor con ese codigo");
					
				}
				break;
			default:
				System.out.println("Valor no valido");
				break;
			}
		}while(opcion!=0);
	}

	
	
	public static void manuopciones() {
		String frase = "0) Salir del programa\n1) Insertar un trabajador en el fichero binario\n2) Consultar todos los escritores del fichero binario."
				+ "\n3) Consultar un trabajador, por código, del fichero binario\n4) Actualizar un escritor, por código, del fichero binario.\r\n"
				+ "";
		System.out.println(frase);
	}
}
