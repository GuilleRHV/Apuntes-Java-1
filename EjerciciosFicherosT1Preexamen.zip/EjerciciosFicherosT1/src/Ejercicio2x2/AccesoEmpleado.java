package Ejercicio2x2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import Actividad2.Departamento;
import entrada.Teclado;

public class AccesoEmpleado {

	public static boolean codigoValido(String file, String codigo) {
		BufferedReader flujoEntrada = null;
		boolean valido = true;
		try {
			File fichero = new File(file);
			flujoEntrada = new BufferedReader(new FileReader(fichero));

			String linea = flujoEntrada.readLine();
			while (linea != null) {
				// System.out.println(linea);
				String[] lineas = linea.split(";");
				if (codigo.equalsIgnoreCase(lineas[0])) {
					valido = false;
				}
				linea = flujoEntrada.readLine();
			}

		} catch (FileNotFoundException fnfe) {
			System.out.println("Error al abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			System.out.println("Error al leer del fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		} finally {
			try {
				if (flujoEntrada != null) {
					flujoEntrada.close();
				}
			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}
		return valido;
	}

	/**
	 * @param url  an absolute URL giving the base location of the image
	 * @param name the location of the image, relative to the url argument
	 * @return the image at the specified URL
	 * @see Image
	 */
	public static boolean codigoDepartamentoValido(String file, String codigo) {
		BufferedReader flujoEntrada = null;
		boolean valido = false;
		try {
			File fichero = new File(file);
			flujoEntrada = new BufferedReader(new FileReader(fichero));

			String linea = flujoEntrada.readLine();
			while (linea != null) {
				// System.out.println(linea);
				String[] lineas = linea.split(";");
				if (codigo.equalsIgnoreCase(lineas[1])) {
					valido = true;
				}
				linea = flujoEntrada.readLine();
			}

		} catch (FileNotFoundException fnfe) {
			System.out.println("Error al abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			System.out.println("Error al leer del fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		} finally {
			try {
				if (flujoEntrada != null) {
					flujoEntrada.close();
				}
			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}
		return valido;
	}

	public static void escribirEmpleado(String filename, Empleado empleado) {
		BufferedWriter flujoSalida = null;
		try {
			File fichero = new File(filename);
			flujoSalida = new BufferedWriter(new FileWriter(fichero, true));
			flujoSalida.write(empleado.toStringWithSeparators());
			flujoSalida.newLine();
			System.out.println("Empleado creado");
		} catch (IOException ioe) {
			System.out.println("Error al escribir en el fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		} finally {
			try {
				if (flujoSalida != null) {
					flujoSalida.close();
				}

			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}
	}

	public List<Empleado> leerempleados(String filename) {
		BufferedReader flujoEntrada = null;
		List<Empleado> lista = new ArrayList<Empleado>();
		try {
			File fichero = new File(filename);
			flujoEntrada = new BufferedReader(new FileReader(fichero));
			int contadorLineas = 0;
			String linea = flujoEntrada.readLine();
			Empleado emp = null;
			while (linea != null) {
				// System.out.println(linea);

				emp = new Empleado(linea);
				lista.add(emp);
				// System.out.println(dep.toString());
				contadorLineas++;
				linea = flujoEntrada.readLine();
			}
			return lista;

		} catch (FileNotFoundException fnfe) {
			System.out.println("Error al abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			System.out.println("Error al leer del fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		} finally {
			try {
				if (flujoEntrada != null) {
					flujoEntrada.close();
				}
			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}
		return lista;
	}

	public Empleado encontrarempleado(String filename, String id) {
		BufferedReader flujoEntrada = null;
		Empleado emp = null;
		try {
			File fichero = new File(filename);
			flujoEntrada = new BufferedReader(new FileReader(fichero));
			int contadorLineas = 0;
			String linea = flujoEntrada.readLine();
			emp = null;
			while (linea != null) {
				// System.out.println(linea);
				String lineas[] = linea.split(";");

				if (lineas[0].equals(id)) {
					emp = new Empleado(linea);

				}

				// System.out.println(dep.toString());
				contadorLineas++;
				linea = flujoEntrada.readLine();
			}

		} catch (FileNotFoundException fnfe) {
			System.out.println("Error al abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			System.out.println("Error al leer del fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		} finally {
			try {
				if (flujoEntrada != null) {
					flujoEntrada.close();
				}
			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}
		return emp;
	}

	public void actualizarEmpleado(String filename, String id, Empleado e) {
		BufferedReader flujoEntrada = null;
		BufferedWriter flujoSalida = null;
		try {
			File fichero = new File(filename);
			flujoEntrada = new BufferedReader(new FileReader(fichero));

			List<String> aux = new ArrayList<String>();
			boolean encontrado = false;
			String linea = flujoEntrada.readLine();
			Empleado emp = null;
			while (linea != null) {
				String lineas[] = linea.split(";");

				if (lineas[0].equals(id)) {

					aux.add(e.toStringWithSeparators());
					// flujoSalida.write(nuevodepartamento);

				} else {
					aux.add(linea);
					// flujoSalida.write(linea);
				}
				linea = flujoEntrada.readLine();
				// flujoSalida.newLine();
			}

			flujoSalida = new BufferedWriter(new FileWriter(filename));
			for (String string : aux) {
				flujoSalida.write(string);
				flujoSalida.newLine();
			}

		} catch (FileNotFoundException fnfe) {
			System.out.println("Error al abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			System.out.println("Error al leer del fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		} finally {
			try {
				if (flujoEntrada != null) {
					flujoEntrada.close();
				}
				if (flujoSalida != null) {
					flujoSalida.close();
				}
			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}
	}

	public void eliminarEmpleado(String filename, String id) {
		BufferedReader flujoEntrada = null;
		BufferedWriter flujoSalida = null;
		try {
			File fichero = new File(filename);
			flujoEntrada = new BufferedReader(new FileReader(fichero));
			int cont = 0;
			int posicion = 0;
			List<String> aux = new ArrayList<String>();
			boolean encontrado = false;
			String linea = flujoEntrada.readLine();
			Empleado emp = null;
			while (linea != null) {
				String lineas[] = linea.split(";");

				if (lineas[0].equals(id)) {

					posicion = cont;
					aux.add(linea);
					// flujoSalida.write(nuevodepartamento);

				} else {
					aux.add(linea);
					// flujoSalida.write(linea);
				}
				cont++;
				linea = flujoEntrada.readLine();
				// flujoSalida.newLine();
			}

			aux.remove(posicion);

			flujoSalida = new BufferedWriter(new FileWriter(filename));
			for (String string : aux) {
				flujoSalida.write(string);
				flujoSalida.newLine();
			}

		} catch (FileNotFoundException fnfe) {
			System.out.println("Error al abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			System.out.println("Error al leer del fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		} finally {
			try {
				if (flujoEntrada != null) {
					flujoEntrada.close();
				}
				if (flujoSalida != null) {
					flujoSalida.close();
				}
			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}
	}

	public void leerfichero(String filename) {
		BufferedReader flujoEntrada = null;
		try {
			File fichero = new File(filename);
			flujoEntrada = new BufferedReader(new FileReader(fichero));
			int contadorLineas = 0;
			String linea = flujoEntrada.readLine();
			Empleado empleado = null;
			while (linea != null) {
				System.out.println(linea);

				empleado = new Empleado(linea);
				System.out.println(empleado.toString());
				contadorLineas++;
				linea = flujoEntrada.readLine();
			}
			if (contadorLineas > 0) {
				System.out.println("Se han encontrado " + contadorLineas + " departamentos.");
			} else {
				System.out.println("No se han encontrado departamentos");
			}

		} catch (FileNotFoundException fnfe) {
			System.out.println("Error al abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			System.out.println("Error al leer del fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		} finally {
			try {
				if (flujoEntrada != null) {
					flujoEntrada.close();
				}
			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}
	}

	public void consultarDepartamentoporid(String filename, String codigo) {
		BufferedReader flujoEntrada = null;
		List<Empleado> empleados = new ArrayList<Empleado>();
		try {
			File fichero = new File(filename);
			flujoEntrada = new BufferedReader(new FileReader(fichero));
			int contadorLineas = 0;
			String linea = flujoEntrada.readLine();
			Empleado empleado = null;

			while (linea != null) {
				// if()
				linea = flujoEntrada.readLine();
			}
			if (contadorLineas > 0) {
				System.out.println("Se han encontrado " + contadorLineas + " departamentos.");
			} else {
				System.out.println("No se han encontrado departamentos");
			}

		} catch (FileNotFoundException fnfe) {
			System.out.println("Error al abrir el fichero:");
			System.out.println(fnfe.getMessage());
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			System.out.println("Error al leer del fichero:");
			System.out.println(ioe.getMessage());
			ioe.printStackTrace();
		} finally {
			try {
				if (flujoEntrada != null) {
					flujoEntrada.close();
				}
			} catch (IOException ioe) {
				System.out.println("Error al cerrar el fichero:");
				System.out.println(ioe.getMessage());
				ioe.printStackTrace();
			}
		}
	}

}
