package Ejercicio2x2;

import java.util.List;

import Actividad2.AccesoDepartamento;
import Actividad2.Departamento;
import entrada.Teclado;

public class Actividad2x2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int id,dia,mes,anyo;
		String codigo,codigodepartamento,nombre;
		double salario;
		
		AccesoEmpleado accesoempleado=new AccesoEmpleado();
		Empleado empleado;
		Departamento dep;
		//accesodepartamento.indicefinal();
		
		
		int opcion;
		do {
			textoOpciones();
			 opcion= Teclado.leerEntero("Introduce opcion");
			 switch (opcion) {
			case 0: 
				break;
			case 1:
				
				
				codigo = Teclado.leerCadena("Introduce codigo");
				if(!accesoempleado.codigoValido("empleados.txt",codigo)) {
					System.out.println("Codigo repetido");
					break;
				}
				codigodepartamento=Teclado.leerCadena("Introduce codigo departamento");
				if(!accesoempleado.codigoDepartamentoValido("departamentos.txt",codigodepartamento)) {
					System.out.println("No hay ningun departamento con este codigo");
					break;
				}
				
				nombre = Teclado.leerCadena("Introduce nombre");
				dia = Teclado.leerEntero("Introduce dia de alta");
				mes = Teclado.leerEntero("Introduce mes de alta");
				anyo = Teclado.leerEntero("Introduce anyo de alta");
				salario = Teclado.leerReal("Introduce salario");
				empleado = new Empleado(codigo, codigodepartamento, nombre, salario, dia, mes, anyo);
				
				accesoempleado.escribirEmpleado("empleados.txt", empleado);
				
				break;
			case 2:
				List<Empleado> lista = accesoempleado.leerempleados("empleados.txt");
				for (Empleado emp : lista) {
					
					System.out.println(emp.toString());
				}
				break;
				
			case 3:
				codigo = Teclado.leerCadena("Introduce codigo del empleado que quieras buscar");
				empleado = accesoempleado.encontrarempleado("empleados.txt", codigo);
				if(empleado!=null) {
					System.out.println(empleado.toString());
				}else {
					System.out.println("No se ha encontrado ningun empleado con el codigo "+codigo);
				}
				break;
				
			case 4:
				
				
				String codigoinicial = Teclado.leerCadena("Introduce codigo del empleado que quieras buscar");
				empleado = accesoempleado.encontrarempleado("empleados.txt", codigoinicial);
				if(empleado!=null) {
					codigo = Teclado.leerCadena("Introduce codigo");
					if(!accesoempleado.codigoValido("empleados.txt",codigo)) {
						System.out.println("Codigo repetido");
						break;
					}
					codigodepartamento=Teclado.leerCadena("Introduce codigo departamento");
					if(!accesoempleado.codigoDepartamentoValido("departamentos.txt",codigodepartamento)) {
						System.out.println("No hay ningun departamento con este codigo");
						break;
					}
					nombre = Teclado.leerCadena("Introduce nombre");
					dia = Teclado.leerEntero("Introduce dia de alta");
					mes = Teclado.leerEntero("Introduce mes de alta");
					anyo = Teclado.leerEntero("Introduce anyo de alta");
					salario = Teclado.leerReal("Introduce salario");
					empleado = new Empleado(codigo, codigodepartamento, nombre, salario, dia, mes, anyo);
					//Actualiza el empleado
					
					accesoempleado.actualizarEmpleado("empleados.txt",codigoinicial,empleado);
					System.out.println("Empleado actualizado");
					
					
				}else {
					System.out.println("No se ha encontrado ningun empleado con el codigo "+codigoinicial);
				}
				break;
				
			case 5:
				String codigoeliminar = Teclado.leerCadena("Introduce codigo del empleado que quieras buscar");
				empleado = accesoempleado.encontrarempleado("empleados.txt", codigoeliminar);
				if(empleado!=null) {
					accesoempleado.eliminarEmpleado("empleados.txt", codigoeliminar);
				}else {
					System.out.println("No existe ningun empelado con este codigo");
				}
				//eliminarEmpleado
				break;
			
			default:
				System.out.println("La opción de menú debe estar comprendida entre 0 y 6");
				break;
			}
		}while(opcion!=0);
	}

	
	
	
	public static void textoOpciones() {
		System.out.println("0) Salir del programa");
		System.out.println("1) Insertar un empleado en el fichero de texto");
		System.out.println("2) Consultar todos los empleados del fichero de texto.");
		System.out.println("3) Consultar un empleados, por código, del fichero de texto");
		System.out.println("4) Actualizar un empleados, por código, del fichero de texto.");
		System.out.println("5) Eliminar un empleado, por código, del fichero de texto");
	
	}
	

}
