package Ejercicio2x2;

public class Empleado {
	
	final String SEPARADOR = ";";
	String codigo;
	String codigodepartamento;
	String nombre;
	double salario;
	Fecha fechaalta;
	public Empleado(String codigo, String codigodepartamento, String nombre, double salario, int dia,int mes,int anyo) {
		super();
		this.codigo = codigo;
		this.codigodepartamento = codigodepartamento;
		this.nombre = nombre;
		this.salario = salario;
		this.fechaalta = new Fecha(dia, mes, anyo);
	}
	
	public Empleado(String datos) {
		String[] palabras = datos.split(";");

		this.codigo=palabras[0] ;
		this.codigodepartamento=palabras[1];
		this.nombre=palabras[2];
		this.salario=Double.parseDouble(palabras[3].replace(",","."));
		String[]fecha=palabras[4].split("/");
		this.fechaalta=new Fecha(Integer.parseInt(fecha[0]),Integer.parseInt(fecha[1]), Integer.parseInt(fecha[2]));
		
	}

	@Override
	public String toString() {
		return "Empleado [codigo=" + codigo + ", codigodepartamento=" + codigodepartamento + ", nombre=" + nombre
				+ ", salario=" + salario + ", fechaalta=" + fechaalta + "]";
	}
	
	
	public String toStringWithSeparators() {
		return this.codigo+SEPARADOR+this.codigodepartamento+SEPARADOR+this.nombre+SEPARADOR+this.salario+SEPARADOR+this.fechaalta.toStringWithSeparators();
	}
	
	
}
