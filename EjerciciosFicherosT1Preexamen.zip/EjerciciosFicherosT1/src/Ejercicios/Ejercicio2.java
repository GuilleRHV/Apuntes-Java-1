package Ejercicios;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import entrada.Teclado;
public class Ejercicio2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		String ruta = Teclado.leerCadena("Introduce ruta del fichero:\n");
		File file = new File(ruta);
		BufferedReader flujoEntrada = null;
		BufferedWriter flujoSalida = null;
		if (!file.exists()) {
			System.out.println("No existe en el sistema de directorios");
			if(!file.isFile()) {
				System.out.println("El archivo no es un fichero.");
			}


		}else {

			try {
				File fichero = new File("estadisticas.txt");
				flujoSalida = new BufferedWriter(new FileWriter(fichero,false));

				flujoEntrada = new BufferedReader(new FileReader(file));
				List<Integer> contadorPalabras = new ArrayList<Integer>();
				int contadorPalabrasTotal =0;
				List<Integer> contadorLetras = new ArrayList<Integer>();
				int contadorLetrasTotal=0;
				
				String linea = flujoEntrada.readLine(); 
				int contLineas = 0;
				while (linea != null) { 	 

					String[] palabras = linea.split("\\s+");

					contadorPalabras.add(palabras.length);
					contadorPalabrasTotal+=palabras.length;
					System.out.println(linea);
					contadorLetras.add(linea.length());
					contadorLetrasTotal+=linea.length();
					linea = flujoEntrada.readLine();
					contLineas++;
				}

				for(int i=0;i<contLineas;i++) {
					flujoSalida.write("Línea "+(i+1)+": "+contadorLetras.get(i)+" caracteres y "+contadorPalabras.get(i)+" palabras");
					flujoSalida.newLine();
				}
				flujoSalida.write("Total:"+contLineas+" líneas,"+contadorLetrasTotal+" caracteres y "+contadorPalabrasTotal+" palabras");




			}catch(Exception e) {
				System.out.println(e.getMessage());
			}
			finally {
				try {
					if(flujoEntrada!=null) {
						flujoEntrada.close();
					}
					if(flujoSalida!=null) {
						flujoSalida.close();
					}

				} catch (Exception e2) {
					// TODO: handle exception
				}
			}	
		}
	}

}
