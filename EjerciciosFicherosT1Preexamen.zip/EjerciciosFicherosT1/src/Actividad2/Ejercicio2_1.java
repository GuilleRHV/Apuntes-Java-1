package Actividad2;

import java.io.IOException;

import entrada.Teclado;

public class Ejercicio2_1 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		int id;
		final String filename = "departamentos.txt";

		AccesoDepartamento accesodepartamento = new AccesoDepartamento();
		
		accesodepartamento.indicefinal();
		// textoOpciones();

		int opcion;
		do {
			textoOpciones();
			opcion = Teclado.leerEntero("Introduce opcion");
			switch (opcion) {
			case 0:
				break;
			case 1:
				accesodepartamento.crearDepartamento();
				break;
			case 2:
				accesodepartamento.leerfichero(filename);
				break;
			case 3:
				id = Teclado.leerEntero("Introduce id");
				accesodepartamento.consultarporid(filename, id);
				break;
			case 4:
				int ids = Teclado.leerEntero("Introduce id");
				accesodepartamento.actualizarDepartamento("departamentos.txt", ids);
				break;
			case 5:
				int ideliminar = Teclado.leerEntero("Introduce id");
				accesodepartamento.eliminarDepartamento("departamentos.txt", ideliminar);
				break;

			default:
				System.out.println("La opción de menú debe estar comprendida entre 0 y 6");
				break;
			}

		} while (opcion != 0);
		
		;
	}

	public static void textoOpciones() {
		System.out.println("0) Salir del programa");
		System.out.println("1) Insertar un departamento en el fichero de texto");
		System.out.println("2) Consultar todos los departamentos del fichero de texto.");
		System.out.println("3) Consultar un departamento, por código, del fichero de texto");
		System.out.println("4) Actualizar un departamento, por código, del fichero de texto.");
		System.out.println("5) Eliminar un departamento, por código, del fichero de texto.");

	}

}
